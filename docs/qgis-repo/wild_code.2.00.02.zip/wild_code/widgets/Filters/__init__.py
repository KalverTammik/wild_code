"""Filter widgets package. Import submodules explicitly."""
