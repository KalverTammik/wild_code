"""Deprecated experimental module feed builder (unused).

Safe to delete this file if no longer needed.
"""
