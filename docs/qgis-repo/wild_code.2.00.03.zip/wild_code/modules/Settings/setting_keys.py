class SettingDialogPlaceholders:
    PROJECTS_SOURCE_FOLDER = "Projects source folder"
    PROJECTS_TARGET_FOLDER = "Projects target folder"
    PROJECTS_PHOTO_FOLDER = "Projects photo folder"
    PROJECTS_PREFERED_FOLDER_NAME_STRUCTURE = "name structure"  # legacy bool flag
    PROJECTS_PREFERED_FOLDER_NAME_STRUCTURE_ENABLED = PROJECTS_PREFERED_FOLDER_NAME_STRUCTURE
    PROJECTS_PREFERED_FOLDER_NAME_STRUCTURE_RULE = "name structure rule"

    SHP_LAYER_NAME = "SHP layer name"