"""Backward-compatible re-export. Prefer utils/auth/user_utils.py."""

from ....utils.auth.user_utils import UserUtils

__all__ = ["UserUtils"]