TRANSLATIONS = {
    "Contract module loaded!": "Lepingu moodul laaditud!"
}
