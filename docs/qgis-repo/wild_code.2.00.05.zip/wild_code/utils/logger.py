from ..Logs.logger import debug, error, info, is_debug, set_debug, warn
