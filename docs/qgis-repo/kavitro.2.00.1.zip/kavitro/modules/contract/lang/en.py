TRANSLATIONS = {
    "Contract module loaded!": "Contract module loaded!"
}
