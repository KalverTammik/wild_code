

# 🟨 **REEGLID**

Siia faili kogume kõik arendusideed, mõtted ja tulevased plaanid. Ideede faili sisu on jagatud kolme plokki: Reeglid, Uued ideed ja Lõpetatud ideed.
Kui tekib uus idee, lisatakse see automaatselt plokki "Uued ideed" koos lisamise kuupäeva, vastutaja ja lühikirjeldusega. Selle ploki ideede ette tuleb staatus TEHA (alati esimene valik) või POOLELI.
Kui idee on läbi käidud ja korraldus antud see lõpetada, siis liigub see automaatselt "Lõpetatud ideed" plokki ja saab staatuse idee kirjelduse ette LÕPETATUD ning lisaks alustamise kuupäevale ka lõpetamise kuupäeva.

Näide uue idee lisamiseks:

🟢 TEHA YYYY-MM-DD: <idee pealkiri>
	- Vastutaja: <nimi>
	- Lühikirjeldus või peamised sammud
```
## Vastutajate legend
- 🟠 Anneli
- 🔵 Kalver
- ⚪ Määramata

